# IT Business Analyst Plugin
## Financial Services & Insurance Edition

A comprehensive Claude plugin for IT Business Analysis in **insurance, reinsurance, and financial services**. Designed for BAs working in life & health, P&C, London Market, and reinsurance programmes.

## Domain Specificity

> **This plugin is purpose-built for insurance and financial services.** All templates, glossaries, regulatory checklists, process patterns, and examples are tailored to this domain. While the BA frameworks (BRD structure, user story format, RACI, etc.) are transferable to other industries, the domain vocabulary, regulatory checklists, data patterns, and estimation multipliers are insurance-specific.

## What's Included

### Core BA Deliverables
- **Requirements documentation** — BRD, FRD, user stories, epics, themes with acceptance criteria
- **Process flows** — Interactive HTML workflow diagrams (presentation-ready) + Mermaid for inline use
- **Stakeholder management** — RACI matrices, stakeholder maps, power-interest grids, communication plans
- **Gap analysis & impact assessment** — Current vs future state mapping, change delta documentation

### Data & Traceability
- **Data dictionary & data mapping** — Field catalogues, source-to-target mappings, transformation rules
- **Requirements traceability matrix (RTM)** — Forward/backward/regulatory traceability with conditional formatting

### Source Ingestion
- **Existing knowledge base docs** — Extract and synthesise from functional specs, design documents, prior BRDs
- **Call transcripts & meeting notes** — Mine stakeholder interviews for requirements, decisions, contradictions
- **Wiki pages & PRDs** — Decompose product requirements into epics and stories with traceability

### Practical BA Tools
- **Estimation support** — Story points, T-shirt sizing, complexity scoring with insurance-specific multipliers
- **Stakeholder communications** — Templates for status updates, change requests, steering briefs, escalation emails
- **Regulatory impact checklists** — Pre-built for Solvency II, IDD, GDPR, FCA Consumer Duty, Lloyd's standards
- **Glossary & acronym manager** — Auto-generates glossaries with 60+ insurance domain terms built in

### Cross-Cutting Behaviours (automatic)
- Glossary auto-generation on every document
- Regulatory impact scanning on any change-related deliverable
- Estimation readiness indicators on stories and epics
- Traceability IDs on all requirements by default

## Installation

### Claude.ai (Web/Desktop)
1. Download the plugin ZIP
2. Go to **Customize → Skills → "+" → Upload**
3. Upload the ZIP file
4. The skill appears in your skills list and triggers automatically

### Claude Code
```bash
# From a marketplace (if published)
/plugin install it-business-analyst@marketplace-name

# Or local install
claude --plugin-dir ./it-business-analyst-plugin
```

### Team / Enterprise
Organization owners can provision this plugin for all users through organization settings, making it available to every BA on the team automatically.

## Usage

Just describe what you need in natural language. The plugin triggers automatically when you mention requirements, process flows, stakeholder analysis, data mapping, estimation, or any BA deliverable. Examples:

- "Write user stories for the claims automation project"
- "Create a RACI for the underwriting transformation programme"
- "Build a data dictionary for the policy administration system"
- "Draft a steering committee update for Sprint 5"
- "Assess the regulatory impact of introducing AI-assisted underwriting"
- "Here's the workshop transcript — extract requirements and produce a BRD"

## File Structure

```
it-business-analyst-plugin/
├── .claude-plugin/
│   └── plugin.json                          # Plugin manifest
├── skills/
│   └── it-business-analyst/
│       ├── SKILL.md                         # Main skill instructions
│       ├── references/
│       │   ├── requirements-guide.md        # BRD, FRD, user stories
│       │   ├── process-modelling-guide.md   # BPMN, swimlanes, Mermaid
│       │   ├── stakeholder-guide.md         # RACI, stakeholder analysis
│       │   ├── gap-analysis-guide.md        # Gap analysis, impact assessment
│       │   ├── source-ingestion-guide.md    # Docs, transcripts, wiki ingestion
│       │   ├── data-dictionary-guide.md     # Data dictionary, S2T mapping
│       │   ├── traceability-matrix-guide.md # RTM, coverage analysis
│       │   ├── estimation-guide.md          # Story points, T-shirt sizing
│       │   ├── communications-guide.md      # Status updates, steering briefs
│       │   ├── regulatory-checklists.md     # Solvency II, IDD, GDPR, FCA, Lloyd's
│       │   └── glossary-guide.md            # Insurance domain glossary
│       └── templates/
│           └── process-flow-template.html   # Interactive workflow template
└── README.md
```
